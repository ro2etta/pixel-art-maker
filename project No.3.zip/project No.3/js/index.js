
function makeGrid() { //to start the creation of the grid
 let canvas = document.getElementsByTagName('table')[0]; //I used the element type name to use
 let height = document.getElementById('height').value;//I gave the element an ID to use
 let width  = document.getElementById('width').value;

 while (canvas.firstChild) { //to clean the table from the previous cells whenever we press on submit
    canvas.removeChild(canvas.firstChild);
}


 for ( i = 0; i < height; i++) { //I used the for loop to start filling the height and width as a table
   let row = document.createElement('tr');

   for ( j = 0; j < width; j++){
     let col = document.createElement('td');

     col.addEventListener('click', function(){
       let colorPicker =  document.getElementById('colorPicker').value;
        this.style.backgroundColor = colorPicker;
     });

     row.appendChild(col); //to add the colomns inside the raws based on the loop counts
   }

  canvas.appendChild(row);//to add the raw to the table after adding the colomns
 }


}

document.getElementById('sizePicker').onsubmit = function(event) {
  event.preventDefault();
  makeGrid();
};
